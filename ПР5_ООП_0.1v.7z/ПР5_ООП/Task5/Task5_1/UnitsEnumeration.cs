﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitsEnumeration
{
    public enum Units
    {
        Metric,
        Imperial
    };
    public enum DeviceType
    {
        Length,
        Mass
    };
}
